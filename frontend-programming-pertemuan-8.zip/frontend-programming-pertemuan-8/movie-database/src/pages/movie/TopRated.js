function TopRatedMovie() {
  return (
    <>
      <h2>Top Rated</h2>
    </>
  );
}

export default TopRatedMovie;
