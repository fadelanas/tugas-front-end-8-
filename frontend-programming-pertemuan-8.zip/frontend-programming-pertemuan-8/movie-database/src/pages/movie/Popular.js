function PopularMovie() {
  return (
    <>
      <h2>Popular Movie</h2>
    </>
  );
}

export default PopularMovie;
