function NowPlayingMovie() {
  return (
    <>
      <h2>Now Playing Movie</h2>
    </>
  );
}

export default NowPlayingMovie;
